// Bitget GM/USDT 오더북 웹소켓 연결 및 데이터 처리
document.addEventListener('DOMContentLoaded', function() {
    // DOM 요소 참조
    const connectionStatus = document.getElementById('connection-status');
    const lastPrice = document.getElementById('last-price');
    const midPrice = document.getElementById('mid-price');
    const spread = document.getElementById('spread');
    const spreadPercent = document.getElementById('spread-percent');
    const bidsContainer = document.getElementById('bids-container');
    const asksContainer = document.getElementById('asks-container');
    const lastPriceRange = document.getElementById('last-price-range');
    const lastPriceBidSum = document.getElementById('last-price-bid-sum');
    const lastPriceAskSum = document.getElementById('last-price-ask-sum');
    const midPriceRange = document.getElementById('mid-price-range');
    const midPriceBidSum = document.getElementById('mid-price-bid-sum');
    const midPriceAskSum = document.getElementById('mid-price-ask-sum');

    // 상태 변수
    let currentLastPrice = 0;
    let currentMidPrice = 0;
    let bids = [];
    let asks = [];
    let websocket = null;
    let reconnectAttempts = 0;
    const maxReconnectAttempts = 5;
    const reconnectDelay = 3000; // 3초

    // 웹소켓 연결 함수
    function connectWebSocket() {
        connectionStatus.className = 'connection-status connecting';
        connectionStatus.textContent = '연결 중...';

        // Bitget 웹소켓 API 연결
        websocket = new WebSocket('wss://ws.bitget.com/v2/ws/public');

        // 연결 이벤트 핸들러
        websocket.onopen = function() {
            connectionStatus.className = 'connection-status connected';
            connectionStatus.textContent = '연결됨';
            reconnectAttempts = 0;
            
            // 오더북 구독 (books5 채널 사용)
            subscribeToOrderbook();
            
            // 30초마다 ping 메시지 전송 (연결 유지)
            startPingInterval();
        };

        // 메시지 수신 이벤트 핸들러
        websocket.onmessage = function(event) {
            const data = JSON.parse(event.data);
            
            // 서버로부터 pong 응답 처리
            if (data === 'pong') {
                console.log('Received pong from server');
                return;
            }
            
            // 오더북 데이터 처리
            if (data.arg && data.arg.channel === 'books5' && data.data) {
                processOrderbookData(data.data);
            }
        };

        // 에러 이벤트 핸들러
        websocket.onerror = function(error) {
            console.error('WebSocket Error:', error);
            connectionStatus.className = 'connection-status disconnected';
            connectionStatus.textContent = '연결 오류 발생';
        };

        // 연결 종료 이벤트 핸들러
        websocket.onclose = function() {
            connectionStatus.className = 'connection-status disconnected';
            connectionStatus.textContent = '연결 종료됨';
            
            // 재연결 시도
            if (reconnectAttempts < maxReconnectAttempts) {
                reconnectAttempts++;
                setTimeout(connectWebSocket, reconnectDelay);
                connectionStatus.textContent = `재연결 시도 중... (${reconnectAttempts}/${maxReconnectAttempts})`;
            } else {
                connectionStatus.textContent = '재연결 실패. 페이지를 새로고침하세요.';
            }
        };
    }

    // 오더북 구독 함수
    function subscribeToOrderbook() {
        if (websocket && websocket.readyState === WebSocket.OPEN) {
            const subscribeMsg = {
                "op": "subscribe",
                "args": [{
                    "instType": "sp",
                    "channel": "books5",
                    "instId": "GMUSDT"
                }]
            };
            websocket.send(JSON.stringify(subscribeMsg));
        }
    }

    // Ping 간격 시작 함수
    let pingInterval = null;
    function startPingInterval() {
        // 기존 인터벌 제거
        if (pingInterval) {
            clearInterval(pingInterval);
        }
        
        // 30초마다 ping 메시지 전송
        pingInterval = setInterval(() => {
            if (websocket && websocket.readyState === WebSocket.OPEN) {
                websocket.send('ping');
            }
        }, 30000);
    }

    // 오더북 데이터 처리 함수
    function processOrderbookData(data) {
        if (!data || !data.bids || !data.asks) return;
        
        // 데이터 저장
        bids = data.bids.map(item => ({
            price: parseFloat(item[0]),
            amount: parseFloat(item[1])
        }));
        
        asks = data.asks.map(item => ({
            price: parseFloat(item[0]),
            amount: parseFloat(item[1])
        }));
        
        // 최고 매수가와 최저 매도가로 mid price 계산
        if (bids.length > 0 && asks.length > 0) {
            const highestBid = bids[0].price;
            const lowestAsk = asks[0].price;
            
            // Last price 업데이트 (최근 거래가, 여기서는 최고 매수가와 최저 매도가의 중간값으로 대체)
            currentLastPrice = (highestBid + lowestAsk) / 2;
            lastPrice.textContent = currentLastPrice.toFixed(4);
            
            // Mid price 계산 및 업데이트
            currentMidPrice = (highestBid + lowestAsk) / 2;
            midPrice.textContent = currentMidPrice.toFixed(4);
            
            // Spread 계산 및 업데이트
            const spreadValue = lowestAsk - highestBid;
            spread.textContent = spreadValue.toFixed(4);
            
            // Spread 퍼센트 계산 및 업데이트
            const spreadPercentValue = (spreadValue / currentMidPrice) * 100;
            spreadPercent.textContent = spreadPercentValue.toFixed(2) + '%';
        }
        
        // 오더북 UI 업데이트
        updateOrderbookUI();
        
        // Depth 분석 업데이트
        updateDepthMetrics();
    }

    // 오더북 UI 업데이트 함수
    function updateOrderbookUI() {
        // 매수 주문(bids) UI 업데이트
        bidsContainer.innerHTML = '';
        bids.forEach(bid => {
            const row = document.createElement('div');
            row.className = 'orderbook-row bid';
            
            const price = document.createElement('div');
            price.className = 'orderbook-price';
            price.textContent = bid.price.toFixed(4);
            
            const amount = document.createElement('div');
            amount.className = 'orderbook-amount';
            amount.textContent = bid.amount.toFixed(4);
            
            const total = document.createElement('div');
            total.className = 'orderbook-total';
            total.textContent = (bid.price * bid.amount).toFixed(2);
            
            row.appendChild(price);
            row.appendChild(amount);
            row.appendChild(total);
            bidsContainer.appendChild(row);
        });
        
        // 매도 주문(asks) UI 업데이트
        asksContainer.innerHTML = '';
        asks.forEach(ask => {
            const row = document.createElement('div');
            row.className = 'orderbook-row ask';
            
            const price = document.createElement('div');
            price.className = 'orderbook-price';
            price.textContent = ask.price.toFixed(4);
            
            const amount = document.createElement('div');
            amount.className = 'orderbook-amount';
            amount.textContent = ask.amount.toFixed(4);
            
            const total = document.createElement('div');
            total.className = 'orderbook-total';
            total.textContent = (ask.price * ask.amount).toFixed(2);
            
            row.appendChild(price);
            row.appendChild(amount);
            row.appendChild(total);
            asksContainer.appendChild(row);
        });
    }

    // Depth 분석 업데이트 함수
    function updateDepthMetrics() {
        if (currentLastPrice <= 0 || currentMidPrice <= 0) return;
        
        // Last Price 대비 ±2% 범위 계산
        const lastPriceLower = currentLastPrice * 0.98;
        const lastPriceUpper = currentLastPrice * 1.02;
        lastPriceRange.textContent = `${lastPriceLower.toFixed(4)} ~ ${lastPriceUpper.toFixed(4)}`;
        
        // Last Price 대비 ±2% 내 매수 호가 합계 계산
        const lastPriceBidSumValue = bids
            .filter(bid => bid.price >= lastPriceLower && bid.price <= currentLastPrice)
            .reduce((sum, bid) => sum + (bid.price * bid.amount), 0);
        lastPriceBidSum.textContent = lastPriceBidSumValue.toFixed(2) + ' USDT';
        
        // Last Price 대비 ±2% 내 매도 호가 합계 계산
        const lastPriceAskSumValue = asks
            .filter(ask => ask.price <= lastPriceUpper && ask.price >= currentLastPrice)
            .reduce((sum, ask) => sum + (ask.price * ask.amount), 0);
        lastPriceAskSum.textContent = lastPriceAskSumValue.toFixed(2) + ' USDT';
        
        // Mid Price 대비 ±2% 범위 계산
        const midPriceLower = currentMidPrice * 0.98;
        const midPriceUpper = currentMidPrice * 1.02;
        midPriceRange.textContent = `${midPriceLower.toFixed(4)} ~ ${midPriceUpper.toFixed(4)}`;
        
        // Mid Price 대비 ±2% 내 매수 호가 합계 계산
        const midPriceBidSumValue = bids
            .filter(bid => bid.price >= midPriceLower && bid.price <= currentMidPrice)
            .reduce((sum, bid) => sum + (bid.price * bid.amount), 0);
        midPriceBidSum.textContent = midPriceBidSumValue.toFixed(2) + ' USDT';
        
        // Mid Price 대비 ±2% 내 매도 호가 합계 계산
        const midPriceAskSumValue = asks
            .filter(ask => ask.price <= midPriceUpper && ask.price >= currentMidPrice)
            .reduce((sum, ask) => sum + (ask.price * ask.amount), 0);
        midPriceAskSum.textContent = midPriceAskSumValue.toFixed(2) + ' USDT';
    }

    // 웹소켓 연결 시작
    connectWebSocket();

    // 페이지 언로드 시 웹소켓 연결 종료
    window.addEventListener('beforeunload', function() {
        if (websocket) {
            websocket.close();
        }
        if (pingInterval) {
            clearInterval(pingInterval);
        }
    });
});
